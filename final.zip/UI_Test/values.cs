﻿/*
 * Created by SharpDevelop.
 * User: hicks_000
 * Date: 01/11/2014
 * Time: 06:21
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace UI_Test
{
	/// <summary>
	/// Description of values.
	/// </summary>
	public class values
	{
		 public string Value { get; set; }
	}
}
